package com.andhika.lets;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
Button btnLogout, btnPinjam, btnStatus, btnTerjadwal, btnRutin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_activity);

        //loadFragment(new HomeFragment());
// inisialisasi BottomNavigaionView
        BottomNavigationView bottomNavigationView = findViewById(R.id.bn_main);
// beri listener pada saat item/menu bottomnavigation terpilih
        bottomNavigationView.setOnNavigationItemSelectedListener(this);


        btnLogout = findViewById(R.id.logout);
        btnPinjam = findViewById(R.id.pinjam);
        btnStatus = findViewById(R.id.status);
        btnRutin = findViewById(R.id.btRutin);
        btnTerjadwal = findViewById(R.id.btTerjadwal);


        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent inToMain = new Intent(HomeActivity.this, MainActivity.class);
                startActivity(inToMain);
            }
        });

        btnPinjam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pinjam = new Intent(HomeActivity.this, PinjamActivity.class);
                startActivity(pinjam);
            }
        });

        btnStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent status = new Intent(HomeActivity.this, StatusActivity.class);
                startActivity(status);
            }
        });

        btnTerjadwal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent jadwal = new Intent(HomeActivity.this, TerjadwalActivity.class);
                startActivity(jadwal);
            }
        });

        btnRutin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent rutin = new Intent(HomeActivity.this, RutinActivity.class);
                startActivity(rutin);
            }
        });



    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fl_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        switch (item.getItemId()){
            case R.id.home_menu:
                Intent home = new Intent(HomeActivity.this, HomeActivity.class);
                startActivity(home);
                break;
            case R.id.add:
                Intent pinjam = new Intent(HomeActivity.this, PinjamActivity.class);
                startActivity(pinjam);
                break;
            case R.id.account_menu:
                fragment = new AccountFragment();
                break;
        }
        return false;
    }
}
