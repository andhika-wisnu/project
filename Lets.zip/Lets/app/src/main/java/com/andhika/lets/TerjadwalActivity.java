package com.andhika.lets;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class TerjadwalActivity extends AppCompatActivity {
    Button btKembali;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terjadwal);



        btKembali=(Button)findViewById(R.id.btKembali);

        btKembali.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View v) {
                                             Intent kembali = new Intent(TerjadwalActivity.this, HomeActivity.class);
                                             startActivity(kembali);
                                         }
                                     }
        );
    }
}


