package com.andhika.lets;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class RutinActivity extends AppCompatActivity {

    Button btKembali;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rutin);

        btKembali=(Button)findViewById(R.id.btKembali);

        btKembali.setOnClickListener(new View.OnClickListener()
                                     {
                                         @Override
                                         public void onClick (View v){
                                             Intent kembali = new Intent(RutinActivity.this, HomeActivity.class);
                                             startActivity(kembali);
                                         }
                                     }
        );
    }
}
