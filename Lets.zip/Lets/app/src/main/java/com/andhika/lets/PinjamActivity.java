package com.andhika.lets;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import static android.text.TextUtils.isEmpty;

public class PinjamActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener, BottomNavigationView.OnNavigationItemSelectedListener {
    //TextView nama_ruangan, status_ruangan, deskripsi_ruangan, IDOrder;
    TextView statusOrder;
    Button btSubmit, btKembali;
    EditText etTglPinjam, etWaktuPinjam, etKeperluan;
    EditText etNamaPeminjam, etNIMNIDN, etStatus;
    Spinner spinnerRuang;
    String ruanganId="";
    Calendar c = Calendar.getInstance();
    int year = c.get(Calendar.YEAR);
    int month = c.get(Calendar.MONTH);
    int day = c.get(Calendar.DAY_OF_MONTH);

    // variable yang merefers ke Firebase Realtime Database
    private DatabaseReference database;
    //FirebaseDatabase database;
    //DatabaseReference ruangan;

    Ruangan currentRuangan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pinjam);

        //loadFragment(new HomeFragment());
// inisialisasi BottomNavigaionView
        BottomNavigationView bottomNavigationView = findViewById(R.id.bn_main);
// beri listener pada saat item/menu bottomnavigation terpilih
        bottomNavigationView.setOnNavigationItemSelectedListener(this);

        //Init firebase
        database = FirebaseDatabase.getInstance().getReference();
        //ruangan = database.getReference("Ruangan");

        //Init view
        btSubmit=(Button)findViewById(R.id.btSubmit);
        btKembali=(Button)findViewById(R.id.btKembali);


        etNIMNIDN =(EditText)findViewById(R.id.nim);
        etNamaPeminjam = (EditText)findViewById(R.id.nama);
        spinnerRuang = (Spinner) findViewById(R.id.spinner);
        etTglPinjam = (EditText)findViewById(R.id.tglPinjam);
        etWaktuPinjam = (EditText)findViewById(R.id.waktuPinjam);
        etKeperluan = (EditText)findViewById(R.id.keperluan);
        etStatus = (EditText)findViewById(R.id.status);
        etStatus.setVisibility(View.GONE);
        etStatus.setText("Belum ACC");

        etTglPinjam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(), "date picker");
            }
        });

        etWaktuPinjam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment timePicker = new TimePickerFragment();
                timePicker.show(getSupportFragmentManager(), "time picker");
            }
        });


        btKembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent kembali = new Intent(PinjamActivity.this, HomeActivity.class);
                startActivity(kembali);
            }
        });

        btSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isEmpty(etNamaPeminjam.getText().toString()) && !isEmpty(etNIMNIDN.getText().toString()) && !isEmpty(spinnerRuang.getSelectedItem().toString()) && !isEmpty(etTglPinjam.getText().toString()) && !isEmpty(etWaktuPinjam.getText().toString()) && !isEmpty(etKeperluan.getText().toString()))
                    submitRuang(new Ruangan(etNIMNIDN.getText().toString(), etNamaPeminjam.getText().toString(), spinnerRuang.getSelectedItem().toString(), etTglPinjam.getText().toString(), etWaktuPinjam.getText().toString(), etKeperluan.getText().toString(), etStatus.getText().toString()));
                else
                    Snackbar.make(findViewById(R.id.btSubmit), "Data Ruangan tidak boleh ada yang kosong", Snackbar.LENGTH_LONG).show();

                InputMethodManager imm = (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(
                        etNIMNIDN.getWindowToken(), 0);
            }
        });
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, month);
        c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        String currentDateString = DateFormat.getDateInstance(DateFormat.FULL).format(c.getTime());

        etTglPinjam.setText(currentDateString);
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        etWaktuPinjam.setText(hourOfDay + ":" + minute);
    }


    private boolean isEmpty(String s) {
        // Cek apakah ada fields yang kosong, sebelum disubmit
        return TextUtils.isEmpty(s);
    }

    private void submitRuang(Ruangan ruang) {
        /**
         * Ini adalah kode yang digunakan untuk mengirimkan data ke Firebase Realtime Database
         * dan juga kita set onSuccessListener yang berisi kode yang akan dijalankan
         * ketika data berhasil ditambahkan
         */
        database.child("ruang").push().setValue(ruang).addOnSuccessListener(this, new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                etNIMNIDN.setText("");
                etNamaPeminjam.setText("");
                etTglPinjam.setText("");
                etWaktuPinjam.setText("");
                etKeperluan.setText("");
                etStatus.setText("Belum ACC");
                Snackbar.make(findViewById(R.id.btSubmit), "Data berhasil ditambahkan", Snackbar.LENGTH_LONG).show();
            }
        });
    }

    public static Intent getActIntent(Activity activity) {
        // kode untuk pengambilan Intent
        return new Intent(activity, PinjamActivity.class);
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fl_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        switch (item.getItemId()){
            case R.id.home_menu:
                Intent home = new Intent(PinjamActivity.this, HomeActivity.class);
                startActivity(home);
                break;
            case R.id.add:
                Intent pinjam = new Intent(PinjamActivity.this, PinjamActivity.class);
                startActivity(pinjam);
                break;
            case R.id.account_menu:
                fragment = new AccountFragment();
                break;
        }
        return false;
    }
}
