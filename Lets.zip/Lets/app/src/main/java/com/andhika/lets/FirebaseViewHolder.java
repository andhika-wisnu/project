package com.andhika.lets;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FirebaseViewHolder extends RecyclerView.ViewHolder {
    public TextView nama, ruangan, tglPinjam, jamPinjam, status;

    public FirebaseViewHolder(@NonNull View itemView){
        super(itemView);

        nama = itemView.findViewById(R.id.nama);
        ruangan = itemView.findViewById(R.id.ruangan);
        tglPinjam = itemView.findViewById(R.id.tglPinjam);
        jamPinjam = itemView.findViewById(R.id.jamPinjam);
        status = itemView.findViewById(R.id.status);

    }
}
